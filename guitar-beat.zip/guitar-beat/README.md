# GUITAR-BEAT

ESP32 (4 buttons) -> Wi-Fi WebSocket -> Node.js server -> browser game.

## Wiring
Buttons: GPIO 13, 12, 14, 27 -> GND (INPUT_PULLUP, no resistor needed)
Optional LEDs: GPIO 26, 25, 33, 32 (220 ohm each) | Buzzer: GPIO 15

## Run
1. `npm install`
2. `npm start`  -> open http://localhost:3000 (test with keys D F J K)
3. Arduino IDE: install "esp32 by Espressif" board + "WebSockets" (Markus Sattler) library.
4. Open esp32_guitar_beat/esp32_guitar_beat.ino, edit ssid / pass / host (PC IP), upload.

PC and ESP32 must be on the same Wi-Fi. Allow Node.js through Windows Firewall (private network).

## Next
- POST /api/results already receives end-of-song stats -> save to MySQL
- Train scikit-learn model, predict skill level, adjust SPEED / note density
